-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Out-2019 às 21:38
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dados_veiculos`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `lucro`
--

CREATE TABLE `lucro` (
  `Loja` double NOT NULL,
  `Consignado` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `lucro`
--

INSERT INTO `lucro` (`Loja`, `Consignado`) VALUES
(0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `veiculos`
--

CREATE TABLE `veiculos` (
  `Nome` varchar(20) NOT NULL,
  `Placa` varchar(8) NOT NULL,
  `Cor` varchar(20) NOT NULL,
  `Preco` double NOT NULL,
  `Ano` int(11) NOT NULL,
  `Status` varchar(12) NOT NULL,
  `Tipo` varchar(12) NOT NULL,
  `Cpf_Propietario` varchar(12) NOT NULL,
  `Propietario` varchar(50) NOT NULL,
  `Taxa` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `veiculos`
--

INSERT INTO `veiculos` (`Nome`, `Placa`, `Cor`, `Preco`, `Ano`, `Status`, `Tipo`, `Cpf_Propietario`, `Propietario`, `Taxa`) VALUES
('Gol Trend 1.0', 'AAA1478', 'Branco', 22000, 2012, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Gol Power 1.6', 'ABC1234', 'Preto', 20500, 2010, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Amarok V6', 'ARK1458', 'Branco', 180000, 2019, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Camaro', 'CAM1598', 'Amarelo', 122900, 2012, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Saveiro Cross', 'CRS3325', 'Branco', 33000, 2012, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Astra', 'EIR5890', 'Prata', 27000, 2010, 'DISPONIVEL', 'CONSIGNADO', '45548658920', 'Osvaldo Beeck', 500),
('Voyage 1.6', 'ELN3665', 'Prata', 24500, 2012, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Uno Mille 1.0', 'ELO1957', 'Verde', 6950, 1994, 'DISPONIVEL', 'CONSIGNADO', '45896587432', 'Elivelton da Silva', 150),
('Peugeot 208', 'FEL4589', 'Branco', 55200, 2018, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Fox 1.0', 'JOA6985', 'Preto', 16300, 2010, 'DISPONIVEL', 'CONSIGNADO', '25865472532', 'Joao Belchior', 300),
('Voyage 1.0', 'MCS4588', 'Preto', 20000, 2011, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Saveiro Super Surf 1', 'SRF8588', 'Prata', 18500, 2007, 'DISPONIVEL', 'LOJA', '------', '------', 0),
('Saveiro Trooper', 'TRP4322', 'Vermelho', 26400, 2011, 'DISPONIVEL', 'CONSIGNADO', '19632587430', 'Joaquim Pereira', 400),
('Uno Vivace 1.0', 'UNO7856', 'Branco', 22500, 2015, 'DISPONIVEL', 'LOJA', '------', '------', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `Cliente` varchar(60) NOT NULL,
  `Placa` varchar(8) NOT NULL,
  `NomeVeiculo` varchar(50) NOT NULL,
  `DataVenda` varchar(50) NOT NULL,
  `Telefone` varchar(50) NOT NULL,
  `Endereço` varchar(50) NOT NULL,
  `PrecoVenda` double NOT NULL,
  `Tipo` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `veiculos`
--
ALTER TABLE `veiculos`
  ADD PRIMARY KEY (`Placa`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
