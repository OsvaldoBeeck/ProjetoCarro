﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoCarro
{
    interface IAvalia1
    {
        void Avaliado(string text);
    }
}
