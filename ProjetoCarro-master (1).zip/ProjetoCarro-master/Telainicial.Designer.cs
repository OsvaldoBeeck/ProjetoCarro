﻿namespace ProjetoCarro
{
    partial class Telainicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Telainicial));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureMinimize = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCadastrarVeiculoLoja = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnPesquisarVeiculo = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnSimulacao = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnVenderVeiculoLoja = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnApresentarVeiculos = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnHistoricoDeVendasDaLoja = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnHistoricoDeVendasConsignado = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnSair = new MaterialSkin.Controls.MaterialFlatButton();
            this.xuiObjectAnimator1 = new XanderUI.XUIObjectAnimator();
            this.button_Lucro = new MaterialSkin.Controls.MaterialFlatButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureMinimize);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureClose);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(869, 78);
            this.panel1.TabIndex = 12;
           
            // pictureMinimize
            // 
            this.pictureMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureMinimize.Image = ((System.Drawing.Image)(resources.GetObject("pictureMinimize.Image")));
            this.pictureMinimize.Location = new System.Drawing.Point(799, 0);
            this.pictureMinimize.Margin = new System.Windows.Forms.Padding(4);
            this.pictureMinimize.Name = "pictureMinimize";
            this.pictureMinimize.Size = new System.Drawing.Size(39, 35);
            this.pictureMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureMinimize.TabIndex = 26;
            this.pictureMinimize.TabStop = false;
            this.pictureMinimize.Click += new System.EventHandler(this.PictureMinimize_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(830, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(386, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "Início";
            // 
            // pictureClose
            // 
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(1049, 4);
            this.pictureClose.Margin = new System.Windows.Forms.Padding(4);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(48, 43);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 1;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.PictureClose_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(142, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnCadastrarVeiculoLoja
            // 
            this.btnCadastrarVeiculoLoja.AutoSize = true;
            this.btnCadastrarVeiculoLoja.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCadastrarVeiculoLoja.Depth = 0;
            this.btnCadastrarVeiculoLoja.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCadastrarVeiculoLoja.Icon = null;
            this.btnCadastrarVeiculoLoja.Location = new System.Drawing.Point(53, 142);
            this.btnCadastrarVeiculoLoja.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnCadastrarVeiculoLoja.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnCadastrarVeiculoLoja.Name = "btnCadastrarVeiculoLoja";
            this.btnCadastrarVeiculoLoja.Primary = false;
            this.btnCadastrarVeiculoLoja.Size = new System.Drawing.Size(194, 36);
            this.btnCadastrarVeiculoLoja.TabIndex = 1;
            this.btnCadastrarVeiculoLoja.Text = "CADASTRAR VEÍCULO";
            this.btnCadastrarVeiculoLoja.UseVisualStyleBackColor = true;
            this.btnCadastrarVeiculoLoja.Click += new System.EventHandler(this.btnCadastrarVeiculoLoja_Click);
            // 
            // btnPesquisarVeiculo
            // 
            this.btnPesquisarVeiculo.AutoSize = true;
            this.btnPesquisarVeiculo.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnPesquisarVeiculo.Depth = 0;
            this.btnPesquisarVeiculo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPesquisarVeiculo.Icon = null;
            this.btnPesquisarVeiculo.Location = new System.Drawing.Point(53, 310);
            this.btnPesquisarVeiculo.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnPesquisarVeiculo.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnPesquisarVeiculo.Name = "btnPesquisarVeiculo";
            this.btnPesquisarVeiculo.Primary = false;
            this.btnPesquisarVeiculo.Size = new System.Drawing.Size(187, 36);
            this.btnPesquisarVeiculo.TabIndex = 4;
            this.btnPesquisarVeiculo.Text = "Pesquisar Veículo";
            this.btnPesquisarVeiculo.UseVisualStyleBackColor = true;
            this.btnPesquisarVeiculo.Click += new System.EventHandler(this.btnPesquisarVeiculo_Click);
            // 
            // btnSimulacao
            // 
            this.btnSimulacao.AutoSize = true;
            this.btnSimulacao.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSimulacao.Depth = 0;
            this.btnSimulacao.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSimulacao.Icon = null;
            this.btnSimulacao.Location = new System.Drawing.Point(719, 132);
            this.btnSimulacao.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnSimulacao.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSimulacao.Name = "btnSimulacao";
            this.btnSimulacao.Primary = false;
            this.btnSimulacao.Size = new System.Drawing.Size(119, 36);
            this.btnSimulacao.TabIndex = 5;
            this.btnSimulacao.Text = "Simulação";
            this.btnSimulacao.UseVisualStyleBackColor = true;
            this.btnSimulacao.Click += new System.EventHandler(this.btnSimulacao_Click);
            // 
            // btnVenderVeiculoLoja
            // 
            this.btnVenderVeiculoLoja.AutoSize = true;
            this.btnVenderVeiculoLoja.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnVenderVeiculoLoja.Depth = 0;
            this.btnVenderVeiculoLoja.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVenderVeiculoLoja.Icon = null;
            this.btnVenderVeiculoLoja.Location = new System.Drawing.Point(53, 254);
            this.btnVenderVeiculoLoja.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnVenderVeiculoLoja.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnVenderVeiculoLoja.Name = "btnVenderVeiculoLoja";
            this.btnVenderVeiculoLoja.Primary = false;
            this.btnVenderVeiculoLoja.Size = new System.Drawing.Size(160, 36);
            this.btnVenderVeiculoLoja.TabIndex = 3;
            this.btnVenderVeiculoLoja.Text = "VENDER VEÍCULO";
            this.btnVenderVeiculoLoja.UseVisualStyleBackColor = true;
            this.btnVenderVeiculoLoja.Click += new System.EventHandler(this.btnVenderVeiculoLoja_Click);
            // 
            // btnApresentarVeiculos
            // 
            this.btnApresentarVeiculos.AutoSize = true;
            this.btnApresentarVeiculos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnApresentarVeiculos.Depth = 0;
            this.btnApresentarVeiculos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnApresentarVeiculos.Icon = null;
            this.btnApresentarVeiculos.Location = new System.Drawing.Point(53, 196);
            this.btnApresentarVeiculos.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnApresentarVeiculos.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnApresentarVeiculos.Name = "btnApresentarVeiculos";
            this.btnApresentarVeiculos.Primary = false;
            this.btnApresentarVeiculos.Size = new System.Drawing.Size(214, 36);
            this.btnApresentarVeiculos.TabIndex = 2;
            this.btnApresentarVeiculos.Text = "Apresentar Veículos";
            this.btnApresentarVeiculos.UseVisualStyleBackColor = true;
            this.btnApresentarVeiculos.Click += new System.EventHandler(this.BtnApresentarVeiculos_Click);
            // 
            // btnHistoricoDeVendasDaLoja
            // 
            this.btnHistoricoDeVendasDaLoja.AutoSize = true;
            this.btnHistoricoDeVendasDaLoja.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnHistoricoDeVendasDaLoja.Depth = 0;
            this.btnHistoricoDeVendasDaLoja.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHistoricoDeVendasDaLoja.Icon = null;
            this.btnHistoricoDeVendasDaLoja.Location = new System.Drawing.Point(548, 196);
            this.btnHistoricoDeVendasDaLoja.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnHistoricoDeVendasDaLoja.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnHistoricoDeVendasDaLoja.Name = "btnHistoricoDeVendasDaLoja";
            this.btnHistoricoDeVendasDaLoja.Primary = false;
            this.btnHistoricoDeVendasDaLoja.Size = new System.Drawing.Size(279, 36);
            this.btnHistoricoDeVendasDaLoja.TabIndex = 6;
            this.btnHistoricoDeVendasDaLoja.Text = "Histórico de vendas da loja";
            this.btnHistoricoDeVendasDaLoja.UseVisualStyleBackColor = true;
            this.btnHistoricoDeVendasDaLoja.Click += new System.EventHandler(this.BtnHistoricoDeVendasDaLoja_Click);
            // 
            // btnHistoricoDeVendasConsignado
            // 
            this.btnHistoricoDeVendasConsignado.AutoSize = true;
            this.btnHistoricoDeVendasConsignado.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnHistoricoDeVendasConsignado.Depth = 0;
            this.btnHistoricoDeVendasConsignado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHistoricoDeVendasConsignado.Icon = null;
            this.btnHistoricoDeVendasConsignado.Location = new System.Drawing.Point(506, 254);
            this.btnHistoricoDeVendasConsignado.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnHistoricoDeVendasConsignado.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnHistoricoDeVendasConsignado.Name = "btnHistoricoDeVendasConsignado";
            this.btnHistoricoDeVendasConsignado.Primary = false;
            this.btnHistoricoDeVendasConsignado.Size = new System.Drawing.Size(319, 36);
            this.btnHistoricoDeVendasConsignado.TabIndex = 7;
            this.btnHistoricoDeVendasConsignado.Text = "Histórico de vendas consignado";
            this.btnHistoricoDeVendasConsignado.UseVisualStyleBackColor = true;
            this.btnHistoricoDeVendasConsignado.Click += new System.EventHandler(this.BtnHistoricoDeVendasConsignado_Click);
            // 
            // btnSair
            // 
            this.btnSair.AutoSize = true;
            this.btnSair.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSair.Depth = 0;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Icon = null;
            this.btnSair.Location = new System.Drawing.Point(383, 355);
            this.btnSair.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btnSair.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnSair.Name = "btnSair";
            this.btnSair.Primary = false;
            this.btnSair.Size = new System.Drawing.Size(59, 36);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // button_Lucro
            // 
            this.button_Lucro.AutoSize = true;
            this.button_Lucro.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button_Lucro.Depth = 0;
            this.button_Lucro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Lucro.Icon = null;
            this.button_Lucro.Location = new System.Drawing.Point(753, 310);
            this.button_Lucro.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.button_Lucro.MouseState = MaterialSkin.MouseState.HOVER;
            this.button_Lucro.Name = "button_Lucro";
            this.button_Lucro.Primary = false;
            this.button_Lucro.Size = new System.Drawing.Size(87, 36);
            this.button_Lucro.TabIndex = 8;
            this.button_Lucro.Text = "LUCROS";
            this.button_Lucro.UseVisualStyleBackColor = true;
            this.button_Lucro.Click += new System.EventHandler(this.button_Lucro_Click);
            // 
            // Telainicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(869, 558);
            this.Controls.Add(this.button_Lucro);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnHistoricoDeVendasConsignado);
            this.Controls.Add(this.btnHistoricoDeVendasDaLoja);
            this.Controls.Add(this.btnApresentarVeiculos);
            this.Controls.Add(this.btnVenderVeiculoLoja);
            this.Controls.Add(this.btnSimulacao);
            this.Controls.Add(this.btnPesquisarVeiculo);
            this.Controls.Add(this.btnCadastrarVeiculoLoja);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Telainicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Página inicial";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureClose;
        private MaterialSkin.Controls.MaterialFlatButton btnCadastrarVeiculoLoja;
        private MaterialSkin.Controls.MaterialFlatButton btnPesquisarVeiculo;
        private MaterialSkin.Controls.MaterialFlatButton btnSimulacao;
        private MaterialSkin.Controls.MaterialFlatButton btnVenderVeiculoLoja;
        private MaterialSkin.Controls.MaterialFlatButton btnApresentarVeiculos;
        private MaterialSkin.Controls.MaterialFlatButton btnHistoricoDeVendasDaLoja;
        private MaterialSkin.Controls.MaterialFlatButton btnHistoricoDeVendasConsignado;
        private MaterialSkin.Controls.MaterialFlatButton btnSair;
        private XanderUI.XUIObjectAnimator xuiObjectAnimator1;
        private MaterialSkin.Controls.MaterialFlatButton button_Lucro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureMinimize;
    }
}